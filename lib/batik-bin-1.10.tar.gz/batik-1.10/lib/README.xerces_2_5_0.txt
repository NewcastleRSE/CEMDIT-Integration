The xerces_2_5_0.jar file comes from the Apache Xerces project
(http://xml.apache.org/dist/xerces-j/), and is licensed under the
Apache Software License, Version 1.1, which is in the
LICENSE.xerces_2_5_0.txt file.
